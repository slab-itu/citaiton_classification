import csv
#import os
#import re
#import nltk
#import scipy
import sklearn.metrics
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn import svm
#from sklearn.externals import joblib
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from scipy import sparse
import numpy as np

def getTrainingAndTestData():
        X = []
        y = []

        #Training data 1: Sentiment 140
       # f=open(r'F:\\ANEELA\\Data\\Altmetrics_Dataset_cleaned.csv','r', encoding='ISO-8859-1')
        f=open(r'PAKDD_Citation_text_stem_stop.csv','r', encoding='ISO-8859-1')
        reader = csv.reader(f)
        i=0
        for row in reader:
            X.append(row[0])
            print("counter", i)
            #X.append(row[1])
#            if row[13]=='positive':
#                y.append(1)
#            elif row[13]=='negative':
#                y.append(-1)
#            else:
#                y.append(0)
            y.append(row[1])
            i=i+1
# =============================================================================
#             print("X text")
#             print(X)
#             print("Y text")
#             print(y)
# =============================================================================
        X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2, random_state=42)
        return X_train, X_test, y_train, y_test

# SVM classifier
def svmClassifier(X_train,y_train):
        
        vec = TfidfVectorizer( min_df=3, max_df=0.1, sublinear_tf = True,use_idf = True,ngram_range=(1,1))
        #print(vec.shape)
        #print("---------------shape-------------------- ")
        #display(vec)
        #svm_clf =svm.SVC(C=1000, gamma=0.00001, kernel='rbf')
        X = vec.fit_transform(X_train)
        #Y = vec.fit_transform(y_train)
        print(vec.get_feature_names())
        print(X.shape)
        print(type(X))
        print(X)
        Z=X.todense()
        print(type(Z))
        print(Z)
       # np.savetxt('vector_without.csv',Z,delimiter=',')
        

        #sparse.save_npz("yourmatrix.npz", X)
        #data = np.load("yourmatrix.npz")
        #print(data.shape)
        #np.savetxt("vector.csv", data, delimiter=",")
        #for key, value in data.items():
        #  np.savetxt("somepath" + key + ".csv", value)
        #your_matrix_back = sparse.load_npz("yourmatrix.npz")
        #numpy.savetxt("foo.csv", X, delimiter=",")
        svm_clf =svm.LinearSVC(C=10,max_iter=100)
        vec_clf = Pipeline([('vectorizer', vec), ('pac', svm_clf)])
        vec_clf.fit(X_train,y_train)
        #print(vec_clf.get_feature_names())
        #print(vec_clf.shape)
        return vec_clf
        
# NB classifier
def NBClassifier(X_train,y_train):
        vec = TfidfVectorizer(min_df=3, max_df=0.8, sublinear_tf = True,use_idf = True,ngram_range=(1,1 ))
        nb_clf = MultinomialNB()
        vec_clf = Pipeline([('vectorizer', vec), ('pac', nb_clf)])
        vec_clf.fit(X_train,y_train)
        return vec_clf

# Main function
def main(arg):
        X_train, X_test, y_train, y_test = getTrainingAndTestData()
        if arg=='nb':
            vec_clf = NBClassifier(X_train,y_train)
        elif arg=='svm':
            vec_clf = svmClassifier(X_train,y_train)
        y_pred = vec_clf.predict(X_test)
        #print(y_pred)
        print(sklearn.metrics.classification_report(y_test,y_pred))  
        print(sklearn.metrics.accuracy_score(y_test, y_pred, normalize=True, sample_weight=None))
        
if __name__ == "__main__":
    model="nb"
    main(arg=model)

    