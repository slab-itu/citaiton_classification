# -*- coding: utf-8 -*-
"""
Created on Mon Oct  8 03:26:53 2018

@author: iqras_000
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Aug  4 17:41:36 2017

@author: iqra
"""

# -*- coding: utf-8 -*-
"""
Created on Sun Jun 12 14:03:32 2016

@author: anam
"""
import numpy as np
from scipy import interp
import matplotlib.pyplot as plt
import pandas as pd
from sklearn import svm
from sklearn.metrics import auc
from sklearn.cross_validation import StratifiedKFold
from sklearn.metrics import precision_recall_curve
from sklearn.metrics import average_precision_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier

###############################################################################


# import some data to play with
mydata = pd.read_csv("vector_processed_featurebased.csv")
y = mydata["Class"]  #provided your csv has header row, and the label column is named "Label"
n_points=len(mydata)
##select all but the last column as data
X = mydata.ix[:,:-1]
X=X.iloc[:,0:536]
# =============================================================================
Ql=X.iloc[:, 0:536 ]
Ct=X.iloc[:, 524:533 ]
Qt=X.iloc[:, 533:536 ]
# 
# =============================================================================
print(Qt)
#X2
#522
#536
#525:533
#534:536

##################################


cv = StratifiedKFold(y, n_folds=5)

y_real = []
y_proba = []

y_real2 = []
y_proba2 = []
y_real4 = []
y_proba4 = []

#######################################################

classifier2= RandomForestClassifier(class_weight='balanced',criterion='entropy')
for i, (train, test) in enumerate(cv):
    x_train2=Ql[train[0]:train[len(train)-1]]
    x_test2=Ql[test[0]:test[len(test)-1]]
    y_train2= y[train[0]:train[len(train)-1]]
    y_test2=y[test[0]:test[len(test)-1]]

    probas_ = classifier2.fit(x_train2, y_train2).predict_proba( x_test2)
    precision, recall, thresholds = precision_recall_curve(y_test2, probas_[:, 1])
   # lab = 'Fold %d AUC=%.4f' % (i+1, auc(recall, precision))
   # plt.plot(recall, precision, lw=1,label=lab)

    y_real2.append(y_test2)
    y_proba2.append(probas_[:, 1])
    
y_real2 = np.concatenate(y_real2)
y_proba2 = np.concatenate(y_proba2)
precision, recall, _ = precision_recall_curve(y_real2, y_proba2)
lab = 'QL Mean AUC=%.2f' % (auc(recall, precision))
print("precision recall QL precisions, recall, fmeasure")
print( np.mean(precision), np.mean(recall),  2*(np.mean(precision)*np.mean(recall))/(np.mean(precision)+np.mean(recall)))
#print(np.mean(precision))
plt.plot(recall, precision, label=lab, lw=2) 
#################################################################

#classifier2= RandomForestClassifier(criterion='entropy')
#classifier= RandomForestClassifier(criterion='entropy')
classifier2 =  RandomForestClassifier(class_weight='balanced',criterion='entropy')
for i, (train, test) in enumerate(cv):
    x_train=Ct[train[0]:train[len(train)-1]]
    x_test=Ct[test[0]:test[len(test)-1]]
    y_train= y[train[0]:train[len(train)-1]]
    y_test=y[test[0]:test[len(test)-1]]
    
    probas_ = classifier2.fit(x_train, y_train).predict_proba( x_test)
    precision, recall, thresholds = precision_recall_curve(y_test, probas_[:, 1])
    #lab = 'Fold %d AUC=%.4f' % (i+1, auc(recall, precision))
   # plt.plot(recall, precision, lw=1)

    y_real.append(y_test)
    y_proba.append(probas_[:, 1])
    
y_real = np.concatenate(y_real)
y_proba = np.concatenate(y_proba)
precision, recall, _ = precision_recall_curve(y_real, y_proba)
lab = 'CT Mean AUC=%.2f' % (auc(recall, precision))

print("precision recall RF CT precision recall fmeasure")
print( np.mean(precision), np.mean(recall), 2*(np.mean(precision)*np.mean(recall))/(np.mean(precision)+np.mean(recall)))
plt.plot(recall, precision, label=lab, lw=2 ) 

classifier2= RandomForestClassifier(class_weight='balanced',criterion='entropy')

for i, (train, test) in enumerate(cv):
    x_train=Qt[train[0]:train[len(train)-1]]
    x_test=Qt[test[0]:test[len(test)-1]]
    y_train= y[train[0]:train[len(train)-1]]
    y_test=y[test[0]:test[len(test)-1]]
    
    probas_ = classifier2.fit(x_train, y_train).predict_proba( x_test)
    precision, recall, thresholds = precision_recall_curve(y_test, probas_[:, 1])
    #lab = 'Fold %d AUC=%.4f' % (i+1, auc(recall, precision))
   # plt.plot(recall, precision, lw=1)

    y_real4.append(y_test)
    y_proba4.append(probas_[:, 1])
    
y_real4 = np.concatenate(y_real4)
y_proba4 = np.concatenate(y_proba4)
precision, recall, _ = precision_recall_curve(y_real4, y_proba4)
lab = 'QT Mean AUC=%.2f' % (auc(recall, precision))
print("precision recall QT precision , recall, fmeasure")
print( np.mean(precision),  np.mean(recall),  2*(np.mean(precision)*np.mean(recall))/(np.mean(precision)+np.mean(recall)))
plt.plot(recall, precision, label=lab, lw=2 ) 


plt.xlim([0.02, 1.00])
plt.ylim([0, 1.05])
plt.grid(True)
plt.xlabel('Recall')
plt.ylabel('Precision')
#plt.title('Mean Precision Recall curve, QL,CT and QT features')
plt.rcParams['axes.facecolor']='white'
plt.legend(loc="lower right")
plt.savefig('Mean_PR_FeatureBased.png')
plt.show()
#xes[1].step(recall, precision, label=lab, lw=2, color='black')
#axes[1].set_xlabel('Recall')
#axes[1].set_ylabel('Precision')
#axes[1].legend(loc='lower left', fontsize='small')

    
    
    